# A TensorFlow implementation of FocalNet
